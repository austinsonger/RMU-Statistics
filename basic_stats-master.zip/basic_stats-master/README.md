# basic_stats
An online introductory course material for business statistics
